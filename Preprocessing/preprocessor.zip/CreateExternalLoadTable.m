function [out_tab] = CreateExternalLoadTable()
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
row_names = {'br_1','br_2','fr_1','fr_2','bl_1','bl_2','fl_1','fl_2'};
col_names = {'F_mean','F_std'};
data = zeros(numel(row_names),2);

for i=1:numel(row_names)
    [f,f_std] = computeExternalLoad(strcat('data/',row_names{i},'.mat'));
    data(i,1) = f;
    data(i,2) = f_std;
end
out_tab = table(data(:,1),data(:,2),'RowNames',row_names,'VariableNames',col_names);
end

