function T = computeLinearSpringTension(F_ext,dx,dy)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
T = F_ext*dx/dy;
end

